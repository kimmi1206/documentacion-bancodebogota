export interface Cliente {
    id: number;
    tipoDocumento: string;
    numeroDocumento: string;
    primerNombre: string;
    segundoNombre: string;
    primerApellido: string;
    segundoApellido: string;
    telefono: string;
    direccion: string;
    ciudadResidencia: string;
  }
  