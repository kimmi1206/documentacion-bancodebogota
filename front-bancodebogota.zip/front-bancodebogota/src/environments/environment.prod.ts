export const environment = {
  production: true,
  URL_BASE: 'https://back-bancodebogota-608870366046.us-central1.run.app/api/v1',
};
