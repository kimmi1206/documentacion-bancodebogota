export const environment = {
  production: true,
  URL_BASE: 'https://someurl.googlecloud.com/prod',
};
