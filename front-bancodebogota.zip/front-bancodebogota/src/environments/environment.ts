export const environment = {
  production: false,
  URL_BASE: 'https://someurl.googlecloud.com/dev',
};
