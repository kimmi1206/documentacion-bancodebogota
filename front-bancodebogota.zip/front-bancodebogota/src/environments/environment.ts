export const environment = {
  production: false,
  URL_BASE: 'http://localhost:8090/api/v1',
};
